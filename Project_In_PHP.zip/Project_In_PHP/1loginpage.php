<?php
   include('pagelogin.php');
   if(isset($_POST['submit'])) 
   {
    $id=$_POST["rn"];
    $name=$_POST["un"];
    $sql="select * from student where name='$name' && id=$id";
      $query= mysqli_query($c,$sql);
      $num=mysqli_num_rows($query);
      #echo "number of row=".$num; 
      if($num > 0) 
      {
        echo '<script>alert("login successfully.")</script>';
          header("location:3Home.html");
           exit();
      }
      else
      { 
        
               
               echo '<script>alert("Sorry Invalid Username and Password. Please Enter Correct Credentials.")</script>';?>
               </b> 

              </font>
             
        <?php
      }
   }  
              
            
?>
<!DOCTYPE html>
<html lang="en">
<head>
     <style>
          .b1{
          
           font-size: 70px;
           font-family:  Times, serif;
           color: rgb(38, 37, 39);
           margin-left: 100px;
          }
        body{
     
          background-repeat: no-repeat;
          background-size: 1300px 650px;
        }
        legend{
          font-size: 40px;
        }
        input{
          font-size: 30px;
          color: rgb(26, 25, 25);
          
        }
        label{
          font-size: 35px;
          font-family: 'Times New Roman', Times, serif;
        }

        .p1{
          font-size: 20px;
        }
        a{
            font-size: 22px;
        }
     </style>
</head>
     <body background="login_1.jpg">
     <form  method="POST"> 
          <center>
        <b class="b1">Login for Student</b>
      <hr>
      <br><br>
                      <pre>
                            <label for="un"><b><i>User Name:</i></b></label> 
                            <input type="text" id="un" name="un" placeholder="Enter User Name" required><br><br>
                      </pre>
                      <pre>
                            <label for="rn"><b><i>ID:</i></b></label>
                            <input type="number" id="rn" name="rn" placeholder="Enter ID" required><br>
                      </pre>
                      <pre>
                            <input type="submit" name="submit" value="Login"><br>
                            <input type="reset" value="Reset"><br>
                            <a href="2createaccount.html">Create an account</a>
                      </pre>
        </center>
     </form>
     </body>

</html>
</html>
<?php
  $c->close();
?>