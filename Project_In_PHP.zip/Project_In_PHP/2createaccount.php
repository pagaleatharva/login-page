<?php
    $id=$_POST['i'];
    $nm=$_POST['f'];
    $cl=$_POST['c'];
    $dv=$_POST['d'];
    $ad=$_POST['a'];
    $ct=$_POST['cno'];
    $c=new mysqli("localhost","root","root","Project_PHP");
    if($c->connect_error){
        die("Connection failed:".$conn->connect_error);
    }
    //$stmt=$c->prepare("insert into student(id,name,class,division,address,contactno) values($id,'$nm','$cl','$dv','$ad',$ct)");
    
    /*if($stmt->execute()){
        echo "successfully inserted";
    }else{
        echo "failed";
    }*/

    $sql="insert into student(id,name,class,division,address,contactno) values($id,'$nm','$cl','$dv','$ad',$ct)";
    if(mysqli_query($c,$sql)==true)
    {
        echo "successfully inserted";
    }
    else{
        echo "Error:".$sql."<br>";
    }
 
    //$stmt->close();
  $c->close();

?>