<?php
 $c=new mysqli("localhost","root","root","Project_PHP");
 if($c->connect_error){
     die("Connection failed:".$c->connect_error);
 }
 

 $sql="select gr_id,gr_name,gr_type,descr from grievance;";
 $result=$c->query($sql);
 
 if(!$result){
    die("Query failed:".$c->error);
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.cs">
</head>
<body>
    <div class="container">
    <h2>List of Grievance</h2>
     <!--<a class="btn btn-primary" href="" role="Button">New Grievance</a>-->
   <br>
   <table style="height: 100px; " border="2" cellpadding="10px" cellspacing="4px">
    <tr style="background-color:rgb(133, 161, 244);">
        <th>gr_id</th>
        <th>gr_name</th>
        <th>gr_type</th>
        <th> descr</th>
        <th colspan="2">View Status</th>
    </tr>
    <tr>
    
    <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
        <td><?php echo $row['gr_id']; ?></td>
        <td><?php echo $row['gr_name']; ?></td>
        <td><?php echo $row['gr_type']; ?></td>
        <td><?php echo $row['descr']; ?></td>
        <td>
                            
                        <td>
                            <button class="btn btn-danger">
                                <a href="delete.php? deleteid=<?php echo $row['gr_id']; ?>">DELETE</a>
                            </button>
                        </td>
    <?php }
    ?>
    </tr>
   
   </table>
</body>
</html>
<?php
$c->close();
?>