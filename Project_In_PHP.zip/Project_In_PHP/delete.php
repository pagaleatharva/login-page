<?php
  $c=new mysqli("localhost","root","root","Project_PHP");
  if($c->connect_error){
      die("Connection failed:".$c->connect_error);
  }
  if(isset($_GET['deleteid'])){
    $id=$_GET['deleteid'];
    $sql="DELETE FROM grievance WHERE gr_id=$id";;
    $result=mysqli_query($c,$sql);
    if($result){
        echo "Deleted successfully";
    }
    else{
         echo "failed to delete ";
    }  
 }
 $c->close();
 ?>