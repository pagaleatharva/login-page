<?php
    $c = new mysqli("localhost", "root", "root", "Project_PHP");

    if ($c->connect_error) {
        die("Connection failed: " . $c->connect_error);
    }

    $sql = "SELECT g.gr_id,s.id,s.name,s.class,s.division,s.address,s.contactno,g.gr_name,g.descr
            FROM student s,grievance g,stud_gr sg
            where s.id=sg.id and g.gr_id=sg.gr_id ";
    $result = $c->query($sql);
    echo "<center><h1> List of Student </h1></center>";
    echo "<style>
        table { 
                        border-collapse: collapse; 
                        width: 100%; 
                        margin-top: 20px;
                        
                    }
                    table, th, td { 
                        border: 1px solid black; 
                        padding: 10px; 

                    }
                         #hp{
                         background:#e4ddf4;
                         color:rgb(31, 30, 30);
                         text-align:center;
                     }
                    #hp a:hover {
                          color: #e8491d;
                      }
                   
                   

    </style>";

    if ($result->num_rows > 0) {
        echo "<table border='1'>
              <tr>
                 
                  <th>Student ID</th>
                  <th>Name</th>
                  
                  <th>Grievance name</th>
                  <th>Grievance descr</th>
                  <th>Class</th>
                  <th>Division</th>
                  <th>Address</th>
                  <th>Contact no</th>
                  
              </tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                   <td>" . $row['id'] . "</td>
                   <td>" . $row['name'] . "</td>
                  <td>" . $row['gr_name'] . "</td>
                  <td>" . $row['descr'] . "</td>
                  <td>" . $row['class'] . "</td>
                  <td>" . $row['division'] . "</td>
                  <td>" . $row['address'] . "</td>
                  <td>" . $row['contactno'] . "</td>
                 
              </tr>";
        }
        echo "<tr id=hp><td colspan='9'><a href='Homeadmin.html'>Previous Page</a></td></tr>";
        echo "</table>";
    } else {
        echo "No Student found";
    }

    $c->close();
?>
