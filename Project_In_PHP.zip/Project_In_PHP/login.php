<?php
   include('pagelogin.php');

   if(isset($_POST['submit'])) {

     // Correct the query to use 'rn' for ID and 'un' for Name
     $sql = mysqli_query($c, "SELECT * FROM student(id,name,class,division,address,contactno) WHERE id='" . $_POST["rn"] . "' AND name='" . $_POST["un"] . "' ");

     $num = mysqli_num_rows($sql); 

     if($num > 0) {
         $row = mysqli_fetch_array($sql);
         // Redirect to check.php after successful login
         header("location:check.php");
         exit();
     } else {
        // Show error message for invalid credentials
        echo "<hr><font color='red'><b><h3>Sorry, Invalid Username and Password.<br>Please Enter Correct Credentials.</h3></b></font><hr>";
     }
   }  
?>

<!DOCTYPE html>
<html lang="en">
<head>
     <style>
          .b1 {
            font-size: 70px;
              font-family: Times, serif;
              color: rgb(38, 37, 39);
          }
          body {
              background-repeat: no-repeat;
              background-size: 1300px 700px;
          }
          legend {
              font-size: 40px;
          }
          input {
              font-size: 30px;
              color: rgb(26, 25, 25);
          }
          label {
              font-size: 35px;
              font-family: 'Times New Roman', Times, serif;
          }
          .p1 {
            font-size: 20px;
          }
          a {
              font-size: 22px;
          }
     </style>
</head>
<body background="download (2).jpeg">
     <form action="3Home.html" method="POST">
          <center>
              <b class="b1">Login for Student</b><br><br>
              <pre>
                  <label for="un"><b><i>User Name:</i></b></label> 
                  <input type="text" id="un" name="un" placeholder="Enter User Name" required><br><br>
              </pre>
              <pre>
                  <label for="rn"><b><i>ID:</i></b></label>
                  <input type="number" id="rn" name="rn" placeholder="Enter ID" required><br>
              </pre>
              <pre>
                  <input type="submit" name="login" value="Login"><br>
                  <input type="reset" value="Reset"><br>
                  <a href="2createaccount.html">Create an account</a>
              </pre>
          </center>
     </form>
</body>
</html>