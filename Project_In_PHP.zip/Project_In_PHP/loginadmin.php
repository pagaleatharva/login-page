<?php
  if (isset($_POST['submit'])) {
    $validId = 12445;
    $validName = "admin";

    if ($_POST['un'] === $validName && $_POST['rn'] == $validId) {
        
        header("Location:Homeadmin.html");
        exit();
    }else
    { 
    echo '<script>alert("Sorry Invalid Username and Password. Please Enter Correct Credentials.")</script>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
     <style>
          .b1{
          
           font-size: 70px;
           font-family:  Times, serif;
           color: rgb(38, 37, 39);
           margin-left: 100px;
          }
        body{
     
          background-repeat: no-repeat;
          background-size: 1300px 650px;
        }
        legend{
          font-size: 40px;
        }
        input{
          font-size: 30px;
          color: rgb(26, 25, 25);
          
        }
        label{
          font-size: 35px;
          font-family: 'Times New Roman', Times, serif;
        }

        .p1{
          font-size: 20px;
        }
        a{
            font-size: 22px;
        }
     </style>
</head>
     <body background="login_1.jpg">
     <form  method="POST"> 
          <center>
        <b class="b1">Login for Admin</b>
      <hr>
      <br><br>
                      <pre>
                            <label for="un"><b><i>Name:</i></b></label> 
                            <input type="text" id="un" name="un" placeholder="Enter User Name" required><br><br>
                      </pre>
                      <pre>
                            <label for="rn"><b><i>ID:</i></b></label>
                            <input type="number" id="rn" name="rn" placeholder="Enter ID" required><br>
                      </pre>
                      <pre>
                            <input type="submit" name="submit" value="Login"><br>
                            <input type="reset" value="Reset"><br>
                           
                      </pre>
        </center>
     </form>
     </body>

</html>
</html>
