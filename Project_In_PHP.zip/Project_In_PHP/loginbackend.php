<?php
// Establish a connection to the MySQL database
$mysqli = new mysqli("localhost", "root", "root", "Project_PHP");

// Check the connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Check if the form is submitted
if (isset($_POST['id']) && isset($_POST['password'])) {
    

    // Prepare and bind
    $sql = mysqli_query($c, "SELECT * FROM student WHERE id='" . $_POST["rn"] . "' AND name='" . $_POST["rn"] . "' ");
   

    // Execute the statement
    $stmt->execute();

    // Store the result
    $stmt->store_result();

    // Check if a matching record is found
    if ($stmt->num_rows > 0) {
        echo "Login successful!";
    } else {
        echo "Invalid ID or password.";
    }

    // Close the statement
    $stmt->close();
}

// Close the connection
$mysqli->close();
?>