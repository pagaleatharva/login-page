<?php
   include('pagelogin.php');
   $message = '';
   if(isset($_POST['submit'])) {
    $id = $_POST["rn"];
    $name = $_POST["un"];
    $sql = "SELECT * FROM student WHERE name='$name' AND id=$id";
    $query = mysqli_query($c, $sql);
    $num = mysqli_num_rows($query);
    if($num > 0) {
        $message = "Login successful.";
    } else {
        $message = "Invalid Username or Password. Please Enter Correct Credentials.";
    }
   }  
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login for Student</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-image: url('login_1.jpg');
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            color: #333;
        }
        .container {
            background: rgba(255, 255, 255, 0.5);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            max-width: 400px;
            width: 100%;
        }
        .container h1 {
            margin-bottom: 20px;
            font-size: 36px;
            color: #4CAF50;
        }
        .container label {
            display: block;
            margin: 10px 0 5px;
            font-size: 18px;
        }
        .container input[type="text"], .container input[type="number"], .container input[type="submit"], .container input[type="reset"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            font-size: 16px;
        }
        .container input[type="submit"], .container input[type="reset"] {
            cursor: pointer;
            background-color: #4CAF50;
            color: white;
            border: none;
            transition: background-color 0.3s ease;
        }
        .container input[type="submit"]:hover, .container input[type="reset"]:hover {
            background-color: #45a049;
        }
        .container a {
            color: #4CAF50;
            font-size: 16px;
            text-decoration: none;
        }
        .container a:hover {
            text-decoration: underline;
        }
        .alert {
            color: red;
            font-size: 16px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Login for Student</h1>
        <?php if ($message): ?>
            <div class="alert"><?php echo $message; ?></div>
        <?php endif; ?>
        <form method="POST"> 
            <label for="un"><b>User Name:</b></label>
            <input type="text" id="un" name="un" placeholder="Enter User Name" required>
            
            <label for="rn"><b>ID:</b></label>
            <input type="number" id="rn" name="rn" placeholder="Enter ID" required>
            
            <input type="submit" name="submit" value="Login">
            <input type="reset" value="Reset">
            
            <p><a href="2createaccount.html">Create an account</a></p>
        </form>
    </div>
</body>
</html>
<?php
  $c->close();
?>


