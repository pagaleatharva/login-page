<?php
   include('loginbackend.php');
   if(isset($_POST['login'])) {
     // Prepare a SQL statement
     $stmt = $c->prepare("SELECT * FROM student WHERE id = ? AND name = ?");
     $stmt->bind_param("is", $_POST["rn"], $_POST["un"]); // bind parameters
     $stmt->execute(); // execute the statement
     $result = $stmt->get_result(); // get the result
     $num = $result->num_rows;
 
     if($num > 0) {
         // If a match is found, redirect to check.php
         header("Location: check.php");
         exit();
     } else {
         // If no match is found, display an error message
         echo '<hr><font color="red"><b><h3>Sorry, invalid username and password. Please enter correct credentials.</h3></b></font><hr>';
     }
 
     // Close the statement
     $stmt->close();
     $c->close();
 }
 
 // Close the database connection
 
 ?>




<!DOCTYPE html>
<html lang="en">
<head>
     <style>
          .b1 { font-size: 70px; font-family: Times, serif; color: rgb(38, 37, 39); }
          body { background-repeat: no-repeat; background-size: 1300px 700px; }
          legend { font-size: 40px; }
          input { font-size: 30px; color: rgb(26, 25, 25); }
          label { font-size: 35px; font-family: 'Times New Roman', Times, serif; }
          .p1 { font-size: 20px; }
          a { font-size: 22px; }
     </style>
</head>
<body background="download (2).jpeg">
     <form action="" method="POST">
          <center>
               <b class="b1">Login for Student</b><br><br>
               <pre>
                     <label for="un"><b><i>User Name:</i></b></label> 
                     <input type="text" id="un" name="un" placeholder="Enter User Name" required><br><br>
               </pre>
               <pre>
                     <label for="rn"><b><i>ID:</i></b></label>
                     <input type="number" id="rn" name="rn" placeholder="Enter ID" required><br>
               </pre>
               <pre>
                     <input type="submit" name="submit" value="Login"><br>
                     <input type="reset" value="Reset"><br>
                     <a href="2createaccount.html">Create an account</a>
               </pre>
          </center>
     </form>
</body>
</html>
