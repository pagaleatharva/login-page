<?php
    
    $c=new mysqli("localhost","root","root","Project_PHP");
    if($c->connect_error){
        die("Connection failed:".$c->connect_error);
    }
    echo "";
    
?>