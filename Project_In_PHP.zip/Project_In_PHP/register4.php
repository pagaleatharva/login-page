<?php
    $grname=$_POST['ch'];
    $grtype=$_POST['gt'];
    $descr=$_POST['descr'];
    $id=$_POST['id'];
    $date=$_POST['dt'];
    $c=new mysqli("localhost","root","root","Project_PHP");
    if($c->connect_error){
        die("Connection failed:".$conn->connect_error);
    }
    //$stmt=$c->prepare("insert into student(id,name,class,division,address,contactno) values($id,'$nm','$cl','$dv','$ad',$ct)");
    
    /*if($stmt->execute()){
        echo "successfully inserted";
    }else{
        echo "failed";
    }*/
    

    $sql="insert into grievance(gr_name,gr_type,descr,regdate)values('$grname',' $grtype','$descr','$date');";
    if(mysqli_query($c,$sql)==true)
    {
        echo "successfully inserted<br>";
    }
    else{
        echo "Error for sql1 query:".$sql."<br>";
    }
   
    $gr_id=$c->insert_id;;
    $sql2="insert into stud_gr(id,gr_id)values($id,$gr_id);";
    if(mysqli_query($c,$sql2)==true)
    {
        echo "successfully inserted";
    }
    else{
        echo "Error for sql2 query:".$sql2."<br>";
    }

    //$stmt->close();
  $c->close();

?>