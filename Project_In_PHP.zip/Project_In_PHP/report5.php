<?php
    $c = new mysqli("localhost", "root", "root", "Project_PHP");

    if ($c->connect_error) {
        die("Connection failed: " . $c->connect_error);
    }
    
    $sql = "SELECT g.gr_id,s.id,s.name,s.class,s.division,g.gr_name ,g.regdate,g.status
            FROM student s,grievance g,stud_gr sg
            where s.id=sg.id and g.gr_id=sg.gr_id and g.status='Resolved'";
    $result = $c->query($sql);

    if ($result==true) {
        echo "<center>";
        echo "<style>
                    table { 
                        border-collapse: collapse; 
                        width: 50%; 
                        margin-top: 20px;
                        
                    }
                    table, th, td { 
                        border: 1px solid black; 
                        padding: 10px; 

                    }
                         #hp{
                         background:#e4ddf4;
                         color:rgb(31, 30, 30);
                         text-align:center;
                     }
                    #hp a:hover {
                          color: #e8491d;
                      }
                    </style>";
        echo "<table >";
        echo "<tr>
                 <th>gr_id</th>
                 <th>Student ID</th>
                 <th>Student name</th>
                 <th>Student Class</th>
                 <th>Student Division</th>
                 <th>Grievance Name</th>
                 <th>Grievance Status</th>
                 <tr>";
        echo "<h1>Student Resolved Status Info</h1>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
            <td>" . $row['gr_id'] . "</td>
            <td>" . $row['id'] . "</td>
            <td>" . $row['name'] . "</td>
            <td>" . $row['class'] . "</td>
            <td>" . $row['division'] . "</td>
            <td>" . $row['gr_name'] . "</td>
            <td>" . $row['status'] . "</td>
        </tr>";
        }
        echo "<tr id=hp><td colspan='7'><a href='Homeadmin.html'>Previous Page</a></td></tr>";
        echo "</center>";
        echo "</table>";
    } else {
        echo "No Student found";
    }

  
   
?>

<?php
  $c->close();

?>
