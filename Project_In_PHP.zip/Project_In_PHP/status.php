<?php
    $c = new mysqli("localhost", "root", "root", "Project_PHP");

    if ($c->connect_error) {
        die("Connection failed: " . $c->connect_error);
    }

    $sql = "SELECT * FROM grievance";
    $result = $c->query($sql);
    echo "<center><h1>Update the Grievance Status</h1></center>";
    echo "<style>
        table { 
                        border-collapse: collapse; 
                        width: 100%; 
                        margin-top: 20px;
                        
                    }
                    table, th, td { 
                        border: 1px solid black; 
                        padding: 10px; 

                    }
                    #hp{
                         background:#e4ddf4;
                         color:rgb(31, 30, 30);
                         text-align:center;
                     }
                    #hp a:hover {
                          color: #e8491d;
                      }
                   

    </style>";

    if ($result->num_rows > 0) {
        echo "<table border='1'>
              <tr>
                  <th>ID</th>
                  <th>Service Type</th>
                  <th>Option</th>
                  <th>Description</th>
                  <th>Registration Date</th>
                  <th>Status</th>
                  <th>Update Status</th>
              </tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                  <td>" . $row['gr_id'] . "</td>
                  <td>" . $row['gr_name'] . "</td>
                  <td>" . $row['gr_type'] . "</td>
                  <td>" . $row['descr'] . "</td>
                  <td>" . $row['regdate'] . "</td>
                  <td>" . $row['status'] . "</td>
                  <td>
                      <form method='post' action='update_status.php'>
                          <input type='hidden' name='gr_id' value='" . $row['gr_id'] . "'>
                          <select name='status'>
                              <option value='Pending'>Pending</option>
                              <option value='In Progress'>In Progress</option>
                              <option value='Resolved'>Resolved</option>
                          </select>
                          <input type='submit' value='Update'>
                      </form>
                  </td>
              </tr>";
             
             
        }
         echo "<tr id=hp><td colspan='7'><a href='Homeadmin.html'>Previous Page</a></td></tr>";
        echo "</table>";
    } else {
        echo "No grievances found";
    }

    $c->close();
?>
