<?php
$c = new mysqli("localhost", "root", "root", "Project_PHP");

if ($c->connect_error) {
    die("Connection failed: " . $c->connect_error);
}

if (isset($_POST['t1'])) {
    $id = $_POST['t1'];
    $sql = "SELECT s.id, s.name, s.class, s.division, g.gr_name, g.status
            FROM student s, grievance g, stud_gr sg
            WHERE s.id = sg.id AND g.gr_id = sg.gr_id AND s.id = $id";
    $result = $c->query($sql);

    if ($result == true) {
        echo "<center>";
        echo "<style>
                body {
                    font-family: Arial, sans-serif;
                    background-color: #f4f4f4;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                }
                table {
                    border-collapse: collapse;
                    width: 100%;
                    margin-top: 20px;
                    background-color: white;
                    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                    margin-bottom: 30px; /* Add margin between tables */
                }
                th, td {
                    border: 1px solid #ddd;
                    padding: 10px;
                    text-align: left;
                }
                th {
                    background-color: #f2f2f2;
                }
                tr:nth-child(even) {
                    background-color: #f9f9f9;
                }
                tr:hover {
                    background-color: #f1f1f1;
                }
                h1 {
                    color: #333;
                }
              </style>";
        echo "<table>";
        echo "<h1>Student Status Info</h1>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr> <td> ID : " . $row['id'] . "</td></tr>";
            echo "<tr> <td> Name : " . $row['name'] . "</td></tr>";
            echo "<tr> <td> Class : " . $row['class'] . "</td></tr>";
            echo "<tr> <td> Division : " . $row['division'] . "</td></tr>";
            echo "<tr> <td> Grievance Name : " . $row['gr_name'] . "</td></tr>";
            echo "<tr> <td> Status : " . $row['status'] . "</td></tr>";
        }
        echo "</table>";
        echo "</center>";
    } else {
        echo "No Student found";
    }
}

$c->close();
?>

