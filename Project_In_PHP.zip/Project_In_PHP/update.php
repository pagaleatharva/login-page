<?php
  $c=new mysqli("localhost","root","root","Project_PHP");
  if($c->connect_error){
      die("Connection failed:".$c->connect_error);
  }
  if(isset($_GET['updid']))
  {
    $id=$_GET['updid'];
    echo "id=".$id;
    if(isset($_POST['submit']))    {
            $grname=$_POST['ch'];
            $grtype=$_POST['gt'];
            $descr=$_POST['descr'];
    $sql="update grievance set gr_name='$grname',gr_type='$grtype',descr='$descr' where gr_id='$id' ";
    $result=mysqli_query($c,$sql);
    if($result){
        echo "Updated successfully";
    }
    else{
         echo "failed to Update ".mysqli_error($c);
    }  
    }
  }
   else {
    die("Update ID not provided.");
}
 $c->close();
?> 
 
<html lang="en">
<head>
    
    <title>Register Grievence Form</title>
    <style>
        body{
                background-repeat: no-repeat;
                background-size: 1300px 700px;
        }
    </style>
</head>
<body background="download (4).jpeg">
    <br><pre style="font-size: 20px;">
    Register Grievence System<BR>
</pre>
        <hr>

<form method="POST" >

Grievence Categories<br>
    <input type="radio" name="ch" value="Food">   Food<br>
    <input type="radio" name="ch" value="Hostel"> Hostel<br>
    <input type="radio" name="ch" value="Library">Library<br><br>
Grievence Type<br>
        <input type="text" name="gt" required><br>
        <p style="font-size: 10px;">Note:In food service:food quality,hygiene,menu variety,etc<br>
        Note:In Hostel service:Cleanliness,maintenance,room allocation,etc<br>
        Note:In Library service:availability of book,internet of speed,etc</p><br><br>
Grievence description<br>
        <textarea rows="7" cols="18" name="descr">Grievence description</textarea><BR><br>
        <input type="submit" value="UPDATE" name="submit" ><br>
        
</form>
</body>
</html>

