<?php
$c=new mysqli("localhost","root","root","Project_PHP");
if($c->connect_error){
    die("Connection failed:".$c->connect_error);
}
if(isset($_GET['updid'])){
  $id=$_GET['updid'];
  echo "id=".$id;
  $sql="update grievance set gr_name='$grname',gr_type='$grtype',descr='$descr' where gr_id='$id' ";
  $result=mysqli_query($c,$sql);
  if($result){
      echo "Update successfully";
  }
  else{
       echo "Update to failed ";
  }  
}
$c->close();

?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Grievance Form</title>
    <style>
        body {
            background-repeat: no-repeat;
            background-size: 1300px 700px;
        }
    </style>
</head>
<body background="download (4).jpeg">
    <br>
    <pre style="font-size: 20px;">
    Register Grievance System
    </pre>
    <hr>

    <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        Grievance Categories<br>
        <input type="radio" name="ch" value="Food"> Food<br>
        <input type="radio" name="ch" value="Hostel"> Hostel<br>
        <input type="radio" name="ch" value="Library"> Library<br><br>
        Grievance Type<br>
        <input type="text" name="gt" required><br>
        <p style="font-size: 10px;">
            Note: In food service: food quality, hygiene, menu variety, etc.<br>
            Note: In Hostel service: cleanliness, maintenance, room allocation, etc.<br>
            Note: In Library service: availability of books, internet speed, etc.
        </p><br><br>
        Grievance description<br>
        <textarea rows="7" cols="18" name="descr">Grievance description</textarea><br><br>
        <input type="submit" name="UPDATE" value="UPDATE"><br>
    </form>
</body>
</html>
