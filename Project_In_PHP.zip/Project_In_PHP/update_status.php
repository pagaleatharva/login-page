<?php
    $gr_id = $_POST['gr_id'];
    $status = $_POST['status'];

    $c = new mysqli("localhost", "root", "root", "Project_PHP");

    if ($c->connect_error) {
        die("Connection failed: " . $c->connect_error);
    }

    $sql = "UPDATE grievance SET status = '$status' WHERE gr_id = $gr_id";
    if ($c->query($sql) === TRUE) {
        echo "Status successfully updated<br>";
    } else {
        echo "Error: " . $sql . "<br>" . $c->error . "<br>";
    }

    $c->close();
?>
